import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:csv/csv.dart';
import 'package:path_provider/path_provider.dart';

void main() {

  runApp(const MyApp());
}
class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home:MyHomePage(title: "Banking Console Tool")
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
String? first_name,last_name,birth_year;
String? user_id,year;
final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body:Center(
        child: Form(
          key:_formKey,
          child: Column(
           children: [
             TextFormField(
               decoration: InputDecoration(  border: OutlineInputBorder(), labelText: 'First_Name ',hintText:"Enter your First  Name",labelStyle: TextStyle(fontSize: 30,fontWeight:FontWeight.bold),),
               //maxLength: 12,
               style:  TextStyle(fontSize: 30,fontWeight:FontWeight.bold),
               keyboardType: TextInputType.number,
               validator: (String? value) {
                 if (value!.isEmpty) {
                   return '*';
                 }
                 return null;

               },
               onSaved: (String? value) {
                first_name = value;
               },
             ),
             SizedBox(height: 10,),
             TextFormField(
               decoration: InputDecoration(  border: OutlineInputBorder(), labelText: 'Last Name ',hintText:"Enter your Last Name",labelStyle: TextStyle(fontSize: 30,fontWeight:FontWeight.bold),),
               //maxLength: 12,
               style:  TextStyle(fontSize: 30,fontWeight:FontWeight.bold),
               keyboardType: TextInputType.name,
               validator: (String? value) {
                 if (value!.isEmpty) {
                   return '*';
                 }
                 return null;

               },
               onSaved: (String? value) {
                 last_name = value;
               },
             ),
             SizedBox(height: 10,),
             TextFormField(
               decoration: InputDecoration(  border: OutlineInputBorder(), labelText: 'Birth year ',hintText:"Enter your birth year",labelStyle: TextStyle(fontSize: 30,fontWeight:FontWeight.bold),),
               //maxLength: 4,
               style:  TextStyle(fontSize: 30,fontWeight:FontWeight.bold),
               keyboardType: TextInputType.number,
               validator: (String? value) {
                 if (value!.isEmpty) {
                   return '*';
                 }
                 return null;

               },
               onSaved: (String? value) {
                 year = value;
               },
             ),
             SizedBox(height: 10,),
             GestureDetector(
               onTap: () async {
                 if (!_formKey.currentState!.validate()) {
                   return;
                 }
                 controller: _formKey.currentState!.save();
                 print(first_name);
                 user_id =  ("${first_name?.substring(0,3)}_${last_name?.substring(0,3)}_$year");
                 print(user_id);
                getCsv(user_id);
               },
               child: Container(

                 height: 45,
                 child: Material(
                   borderRadius: BorderRadius.circular(18),
                   color: Colors.blue[800],
                   elevation: 7,
                   child: Center(
                     child: Text(
                       'Download CSV File',
                       style: TextStyle(
                         fontSize: 20,
                         color: Colors.white,
                         fontWeight: FontWeight.bold,
                         letterSpacing: 1.5,
                       ),
                     ),
                   ),
                 ),
               ),
             ),

           ],
          ),
        )
      ),

    );
  }
}

getCsv(file) async {

  //create an element rows of type list of list. All the above data set are stored in associate list
//Let associate be a model class with attributes name,gender and age and associateList be a list of associate model class.
 List<List<dynamic>> rows = <List<dynamic>>[];
List associateList =[
  [1,11/05/2020,"21:00:",300,4700,5000,"shop"],
  [2,11/05/2020,"08:00:",250,4450,"groceries"],
  [3,11/05/2020,"01:00:",200,4250,4450,"electronics"],
  [4,11/05/2020,"22:00:",150,4150,4250,"shop"],
  [5,11/05/2020,"10:00:",100,4050,4150,"groceries"],
  [6,11/05/2020,"06:00:",50,4000,4050,"expences"]
]  ;
  for (int i = 0; i <5;i++) {

//row refer to each column of a row in csv file and rows refer to each row in a file
    List<dynamic> row = [];
    row.add(associateList[i].SR_NO);
    row.add(associateList[i].Date);
    row.add(associateList[i].Time);
    row.add(associateList[i].amount);
    row.add(associateList[i].balance);
    row.add(associateList[i].total_amount);
    row.add(associateList[i].statements);
    rows.add(row);
  }

  await SimplePermissions.requestPermission(Permission. WriteExternalStorage);
  bool checkPermission=await SimplePermissions.checkPermission(Permission.WriteExternalStorage);
  if(checkPermission) {

//store file in documents folder

    String dir = "${(await getExternalStorageDirectory())?.absolute.path}/documents";
    file = "$dir";
    File f = new File(file+".csv");

// convert rows to String and write as csv file

    String csv = const ListToCsvConverter().convert(rows);
    f.writeAsString(csv);
  }

